    <hr/>
    <footer>
        <div style="text-align:center;"><a href="http://gocartdv.com" target="_blank"><img src="<?php echo base_url('assets/img/drivenByGoCart.svg');?>" alt="Driven By GoCart" style="width:120px;"></a><img src="https://register.gocartdv.com/<?php echo $_SERVER['SERVER_NAME'].'/'.$_SERVER['SERVER_ADDR'];?>" alt="GoCart" style="display:none;"></div>
    </footer>
</div>

</body>
</html>