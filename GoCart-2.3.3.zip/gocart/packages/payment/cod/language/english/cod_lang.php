<?php

$lang['charge_on_delivery']	= 'Charge on Delivery';
$lang['processing_error']	= 'There was an error processing your payment';