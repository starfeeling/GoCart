<table width="100%" border="0" cellpadding="5">
  <tr>
    <td><img  src="https://www.paypal.com/en_US/i/logo/PayPal_mark_180x113.gif" border="0" alt="Acceptance Mark"></td>
  </tr>
  <tr>
    <td><?php echo lang('paypal_desc') ?></td>
  </tr>
</table>
