<table width="100%" border="0" cellpadding="5">
  <tr>
    <td><img src="https://www.2checkout.com/upload/images/logo.png" border="0" width="100" alt="2Checkout"></td>
  </tr>
  <tr>
    <td><?php echo lang('twocheckout_desc') ?></td>
  </tr>
</table>
