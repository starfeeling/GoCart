    <footer class="footer">

        <div style="text-align:center;"><a href="http://gocartdv.com" target="_blank"><img src="<?php echo base_url('assets/img/drivenByGoCart.svg');?>" alt="Driven By GoCart"></a></div>
        
    </footer>
</div>

</body>
</html>